package com.example.tenminutesmeals;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AddMealActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_meal); // سيظهر خط أحمر هنا مؤقتاً
    }
}